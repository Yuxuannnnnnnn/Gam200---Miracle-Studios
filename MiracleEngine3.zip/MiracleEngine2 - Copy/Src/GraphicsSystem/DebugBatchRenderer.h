#pragma once

#include <vector>

class DebugBatchRenderer
{
public:
	std::vector<float> vert;
};