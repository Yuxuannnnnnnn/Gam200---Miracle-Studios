#include "PrecompiledHeaders.h"
#include "DebugBatchRenderer.h"