#pragma once

// a manager class to manage all the camera

class CameraManager
{

};