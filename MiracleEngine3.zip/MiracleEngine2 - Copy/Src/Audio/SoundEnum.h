#pragma once

enum SoundEnum
{
	SHOOT,
	ENEMYDEATH,
};