#define STB_IMAGE_IMPLEMENTATION
#include "PrecompiledHeaders.h"
#include "stb_image.h"
